package com.WorkWave.WorkWave;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkWaveApplicationTests {

	@Test
	void contextLoads() {
	}

}
